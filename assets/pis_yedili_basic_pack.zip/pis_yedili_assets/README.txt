Pis Yedili – Basic Asset Pack
================================

Boyut: 750x1050px (PNG, şeffaf köşeler).
İçerik:
- deck1/ ve deck2/: 52'şer kart (A,2..10,J,Q,K × Sinek/Karo/Kupa/Maça)
- jokers/: 4× Jolly Joker (JJ), 8× Normal Joker (NJ)
- backs/: back_dark.png, back_red.png (kart arkası)

Kullanım (Flutter pubspec.yaml):
--------------------------------
flutter:
  assets:
    - assets/cards/deck1/
    - assets/cards/deck2/
    - assets/cards/jokers/
    - assets/cards/backs/

Notlar:
- Renkler: Karo/Kupa kırmızı, Sinek/Maça siyah.
- JJ/NJ üzerinde köşelerde etiketler (JJ/NJ), ortada ikonlar ve renk şeritleri.
- Telif: Bu set bu üretimde türetilmiştir; kişisel ve ticari projelerde serbestçe kullanılabilir.
- Tarih: 2025-09-11
